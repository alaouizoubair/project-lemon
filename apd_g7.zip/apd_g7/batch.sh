#!/bin/bash

# Script pour lancer gen_models_and_match.sh par lot

unknownFace="test_data/subject10.sad";
tableau=(2 3 5 10 15 20);
for i in ${tableau[*]};
do
	echo "va executer : ./gen_models_and_match.sh $i $unknownFace";
	./gen_models_and_match.sh $i $unknownFace;
done

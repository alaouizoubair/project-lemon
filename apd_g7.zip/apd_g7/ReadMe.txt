le 02/02/2017

Développé par :
Ashfack ABDOUL AZID
Zoubair ALAOUI
Mostapha BOUDJRAF

Groupe 7
INGE INFO 3

Dans le cadre du cours d'Algorithmes Parallèles et Distribués

Tentative de mise en application des concepts vus en cours.
Nous nous sommes basés sur le code de : http://hanzratech.in/2015/02/03/face-recognition-using-opencv.html
Et nous tenons à en remercier l'auteur.

Nous avons tenté de généraliser ce qu'il y avait fait et de paralléliser/distribuer l'apprentissage et la reconnaissance.

Note : ce code a été testé sur une seule machine disposant de 3 processeurs à 3 cpu chacun.


/* Pour lancer */

/* 1. Pour les modèles : nb nombre de modèles désirés, fileList est la liste avec nom des fichiers à apprendre 
	les fichiers doivent respecter la convention de nom suivante : subjectNUMBER.peuImporte,
	si deux fichiers ont le même number, alors le programme considère que c'est la même personne
*/ 

mpiexec -n <nb> python gen_models_distributed.py <fileList>
/* Exemple */
mpiexec -n 10 python gen_models_distributed.py training_data/*


/* 2. Pour la prédiction : 
	filePath est le chemin du fichier à classifier, 
	nb est le nombre de modèles et le nombre de processus (idéalement), mais il ne doit pas être supérieur au nombre de modèles
*/

mpiexec -n <nb> python mpi.py <filePath>
/* Exemple */
mpiexec -n 10 python mpi.py test_data/subject03.sad

/* Un script a été conçu pour automatiser ce traitement */
Si vous voulez juste comparer avec différentes valeurs de nombre de processus, 
faites juste :
./batch.sh

Si vous voulez lancer plus spécifiquement avec un nombre précis (l'apprentissage distribué puis directement la reconnaissance)
./gen_models_and_match.sh <nb modeles> <chemin photo inconnue>
Ex :
./gen_models_and_match.sh 5 test_data/subject01.sad

# -*- coding: utf-8 -*-
#!/usr/bin/python

"""
le 02/02/2017

Développé par :
Ashfack ABDOUL AZID
Zoubair ALAOUI
Mostapha BOUDJRAF

Groupe 7 - INGE INFO 3
"""

# Imports
import cv2, os
import numpy as np
from PIL import Image
import sys
from mpi4py import MPI
#import re # utile si vous voulez la méthode générale
cascadePath = "haarcascade_frontalface_default.xml"
faceCascade = cv2.CascadeClassifier(cascadePath)

# Celle-ci prend en paramètre une liste de fichiers/chemins
# elle retourne une liste d'images (matrice) et une liste de labels (identité, entier, numéro de l'individu)
def get_images_and_labels(image_paths):
    """
    Image paths est l'ensemble d'apprentissage
    """
    images = []
    # labels ou classe pour le classifieur d'open CV , sera un entier
    labels = []
    for image_path in image_paths:
        # Conversion en nuances de gris
        image_pil = Image.open(image_path).convert('L')
        # Conversion en numpy array
        image = np.array(image_pil, 'uint8')
        # Le label
        nbr = int(os.path.split(image_path)[1].split(".")[0].replace("subject", ""))
        # plus général, pour ne conserver que le label
        #nbr = int(re.sub(r"[a-zA-Z]", "", os.path.split(image_path)[1].split(".")[0]))
        # Detection du visage
        faces = faceCascade.detectMultiScale(image)
        # Si l'image est trouvée ...
        for (x, y, w, h) in faces:
            images.append(image[y: y + h, x: x + w])
            labels.append(nbr)
            # Pour afficher l'ajout d'images
            cv2.imshow("Ajout de têtes au modèle d'apprentissage ....", image[y: y + h, x: x + w])
            cv2.waitKey(10)
    # retourne les listes d'images et labels
    return images, labels


# argv[1:] : liste des noms de fichiers pour l'apprentissage
if __name__ == '__main__':
	# Utilisation de LBPH Face Recognizer 
	recognizer = cv2.createLBPHFaceRecognizer()
	fileNames = sys.argv[1:]
	if(len(fileNames) < 1):
		print('usage : py gen_models_distributed.py <liste nom fichiers>')
		exit(-1)
	comm = MPI.COMM_WORLD
	size = comm.Get_size()
	nbModels = size
	rank = comm.Get_rank()
	nbFilesPerModel = int(len(fileNames)/size)
	
	# Chaque processus va avoir nbFilesPerModel dans son modèle, sauf le dernier processus, qui aura ce qui reste
	# Chaque processus aura les fichiers de rank*nbFilesPerModel à (rank+1) * nbFilesPerModel -1
	
	start_time = MPI.Wtime()
	if(rank != size -1):
		print('process', rank, 'treating',rank*nbFilesPerModel,'-',(rank+1) * nbFilesPerModel)
		images, labels = get_images_and_labels(fileNames[rank*nbFilesPerModel : (rank+1) * nbFilesPerModel])
		
	else:
		print('process', rank, 'treating',rank*nbFilesPerModel)
		images, labels = get_images_and_labels(fileNames[rank*nbFilesPerModel:])
	
	cv2.destroyAllWindows()
	recognizer.train(images, np.array(labels))
	recognizer.save("./model" + str(rank+1) + ".xml")
	
	end_time = MPI.Wtime()
	if(rank == size -1):
		print("--- %s secondes en parallèle---" % (end_time - start_time))
	# Pour éviter d'influer sur le temps de la partie séquentielle, on fait un Barrier
	comm.Barrier()
	""" Partie 'séquentielle' """
	if rank == 0:
		start_timeS = MPI.Wtime()
		for i in range(nbModels-1):
			images, labels = get_images_and_labels(fileNames[i*nbFilesPerModel : (i+1) * nbFilesPerModel])
			cv2.destroyAllWindows()
			recognizer.train(images, np.array(labels))
			recognizer.save("./model" + str(i+1) + ".xml")
		images, labels = get_images_and_labels(fileNames[(nbModels-1)*nbFilesPerModel:])
		cv2.destroyAllWindows()
		recognizer.train(images, np.array(labels))
		recognizer.save("./model" + str(nbModels) + ".xml")	
		end_timeS = MPI.Wtime()
		print("--- %s secondes en séquentiel---" % (end_timeS - start_timeS))	
		speedUp = (end_timeS - start_timeS)/(end_time - start_time)
		print("SpeedUp : %f" % (speedUp))
		print("Travail : %f" %( nbModels*(end_time - start_time)))
		print("Efficacité : %f" % (speedUp/ nbModels))
		


#!/bin/bash

# Script permettant de générer les modèles puis de faire la reconnaissance de l'image inconnue
nb=$1;
unknownFace=$2;
echo $nb $unknownFace;
if [ -z $unknownFace ];then
	echo "Usage : $0 <nombre de processus/modèles> <chemin_photo_inconnue>";
	exit 1
fi
fileList="training_data/*"
echo "va executer : mpiexec -n $nb python gen_models_distributed.py $fileList";
mpiexec -n $nb python gen_models_distributed.py $fileList
echo "va executer : mpiexec -n $nb python mpi.py $unknownFace";
mpiexec -n $nb python mpi.py $unknownFace
